### From version 26.1 the firmware for Classic Menu and Unified Menu is merged.

**Now Classic Menu or Unified menu can be enabled using the config.ini file without the need to update the firmware**
