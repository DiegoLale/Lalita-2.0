#ifndef _MYGCODEFS_H_
#define _MYGCODEFS_H_

#include "stdbool.h"
#include "gcode.h"

bool mountGcodeSDCard(void);
bool scanPrintFilesGcodeFs(void);

#endif
