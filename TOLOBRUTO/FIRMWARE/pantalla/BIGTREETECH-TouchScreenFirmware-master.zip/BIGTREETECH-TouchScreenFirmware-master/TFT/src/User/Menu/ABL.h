#ifndef _ABL_H_
#define _ABL_H_

#ifdef __cplusplus
extern "C" {
#endif

#include <stdbool.h>

void ablUpdateStatus(bool succeeded);

void menuABL(void);

#ifdef __cplusplus
}
#endif

#endif
