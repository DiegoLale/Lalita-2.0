#ifndef _BABYSTEP_H_
#define _BABYSTEP_H_

#ifdef __cplusplus
extern "C" {
#endif

void babyReset(void);

void menuBabystep(void);

#ifdef __cplusplus
}
#endif

#endif
