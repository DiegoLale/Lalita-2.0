#ifndef _BED_LEVELING_H_
#define _BED_LEVELING_H_

#ifdef __cplusplus
extern "C" {
#endif

void menuBedLeveling(void);

#ifdef __cplusplus
}
#endif

#endif
