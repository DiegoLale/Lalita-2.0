#ifndef _FAN_H_
#define _FAN_H_

#ifdef __cplusplus
extern "C" {
#endif

void menuFan(void);

#ifdef __cplusplus
}
#endif

#endif
