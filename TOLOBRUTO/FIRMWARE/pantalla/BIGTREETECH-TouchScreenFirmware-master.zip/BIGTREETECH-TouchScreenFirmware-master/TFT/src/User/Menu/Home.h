#ifndef _HOME_H_
#define _HOME_H_

#ifdef __cplusplus
extern "C" {
#endif

void menuHome(void);

#ifdef __cplusplus
}
#endif

#endif
