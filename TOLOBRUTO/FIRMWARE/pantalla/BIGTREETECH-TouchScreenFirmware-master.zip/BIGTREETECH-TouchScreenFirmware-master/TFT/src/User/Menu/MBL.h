#ifndef _MBL_H_
#define _MBL_H_

#ifdef __cplusplus
extern "C" {
#endif

#include <stdbool.h>

void mblUpdateStatus(bool succeeded);

void menuMBL(void);

#ifdef __cplusplus
}
#endif

#endif
