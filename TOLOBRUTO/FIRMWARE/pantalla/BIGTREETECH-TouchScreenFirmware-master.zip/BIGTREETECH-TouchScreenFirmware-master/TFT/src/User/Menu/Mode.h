#ifndef _MODE_H_
#define _MODE_H_

#ifdef __cplusplus
extern "C" {
#endif

void infoMenuSelect(void);

void Serial_ReSourceDeInit(void);
void Serial_ReSourceInit(void);

#ifdef __cplusplus
}
#endif

#endif
