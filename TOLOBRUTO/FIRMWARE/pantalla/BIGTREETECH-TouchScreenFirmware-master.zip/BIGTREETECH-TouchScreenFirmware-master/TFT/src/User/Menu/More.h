#ifndef _MORE_H_
#define _MORE_H_

#ifdef __cplusplus
extern "C" {
#endif

void menuMore(void);

#ifdef __cplusplus
}
#endif

#endif
