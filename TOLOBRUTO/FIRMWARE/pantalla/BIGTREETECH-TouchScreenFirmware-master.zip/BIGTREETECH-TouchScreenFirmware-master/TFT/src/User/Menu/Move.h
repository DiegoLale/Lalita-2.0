#ifndef _MOVE_H_
#define _MOVE_H_

#ifdef __cplusplus
extern "C" {
#endif

void menuMove(void);
void drawXYZ(void);
void update_gantry(void);

#ifdef __cplusplus
}
#endif

#endif
