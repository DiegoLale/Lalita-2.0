#ifndef _NOTIFICAITONMENU_H_
#define _NOTIFICAITONMENU_H_

#ifdef __cplusplus
extern "C" {
#endif

#include "Notification.h"

void menuNotification(void);

#ifdef __cplusplus
}
#endif

#endif
