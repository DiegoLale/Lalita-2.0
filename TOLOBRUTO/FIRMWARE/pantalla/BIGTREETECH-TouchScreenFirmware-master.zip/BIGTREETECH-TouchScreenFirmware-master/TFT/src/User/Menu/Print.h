#ifndef _PRINT_H_
#define _PRINT_H_

#ifdef __cplusplus
extern "C" {
#endif

#include "includes.h"

void menuPrintFromSource(void);
void menuPrint(void);

#ifdef __cplusplus
}
#endif

#endif
