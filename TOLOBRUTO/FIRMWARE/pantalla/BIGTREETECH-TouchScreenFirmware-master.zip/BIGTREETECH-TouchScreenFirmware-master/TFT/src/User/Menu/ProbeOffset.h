#ifndef _PROBE_OFFSET_H_
#define _PROBE_OFFSET_H_

#ifdef __cplusplus
extern "C" {
#endif

void menuProbeOffset(void);

#ifdef __cplusplus
}
#endif

#endif
