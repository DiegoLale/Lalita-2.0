#ifndef _TUNING_H_
#define _TUNING_H_

#ifdef __cplusplus
extern "C" {
#endif

void menuTuning(void);

#ifdef __cplusplus
}
#endif

#endif
