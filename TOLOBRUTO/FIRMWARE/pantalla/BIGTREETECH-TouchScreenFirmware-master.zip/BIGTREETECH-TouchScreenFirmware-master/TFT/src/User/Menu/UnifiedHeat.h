#ifndef _UNIFIEDHEAT_H_
#define _UNIFIEDHEAT_H_

#ifdef __cplusplus
extern "C" {
#endif

void menuUnifiedHeat(void);

#ifdef __cplusplus
}
#endif

#endif
